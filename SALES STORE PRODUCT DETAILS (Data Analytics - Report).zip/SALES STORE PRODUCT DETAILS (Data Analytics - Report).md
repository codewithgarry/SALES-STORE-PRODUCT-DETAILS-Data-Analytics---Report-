# Data Analytics Project 


#IMPORTING THE LIBRARIES


import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt


```python
#IMPORTING THE DATASET
sales = pd.read_csv('F:\Project4/Salesstore.csv')
```


```python
sales.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order_ID</th>
      <th>Order_Priority</th>
      <th>Order_Quantity</th>
      <th>Sales</th>
      <th>Ship_Mode</th>
      <th>Profit</th>
      <th>Customer_Name</th>
      <th>Region</th>
      <th>Customer_Segment</th>
      <th>Product_Category</th>
      <th>Product_Sub-Category</th>
      <th>Product_Name</th>
      <th>Product_Container</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>643</td>
      <td>High</td>
      <td>21</td>
      <td>2781.82</td>
      <td>Express Air</td>
      <td>-695.26</td>
      <td>Monica Federle</td>
      <td>Nunavut</td>
      <td>Corporate</td>
      <td>Office Supplies</td>
      <td>Storage &amp; Organization</td>
      <td>SAFCO Commercial Wire Shelving, Black</td>
      <td>Large Box</td>
    </tr>
    <tr>
      <th>1</th>
      <td>8995</td>
      <td>High</td>
      <td>35</td>
      <td>3389.93</td>
      <td>Express Air</td>
      <td>737.94</td>
      <td>Beth Paige</td>
      <td>Northwest Territories</td>
      <td>Consumer</td>
      <td>Furniture</td>
      <td>Office Furnishings</td>
      <td>Luxo Professional Combination Clamp-On Lamps</td>
      <td>Large Box</td>
    </tr>
    <tr>
      <th>2</th>
      <td>9127</td>
      <td>Not Specified</td>
      <td>7</td>
      <td>2039.56</td>
      <td>Express Air</td>
      <td>-329.49</td>
      <td>Bryan Davis</td>
      <td>Northwest Territories</td>
      <td>Corporate</td>
      <td>Office Supplies</td>
      <td>Storage &amp; Organization</td>
      <td>Tennsco Snap-Together Open Shelving Units, Sta...</td>
      <td>Large Box</td>
    </tr>
    <tr>
      <th>3</th>
      <td>26272</td>
      <td>Low</td>
      <td>6</td>
      <td>905.94</td>
      <td>Express Air</td>
      <td>-4.19</td>
      <td>Carlos Daly</td>
      <td>Northwest Territories</td>
      <td>Home Office</td>
      <td>Furniture</td>
      <td>Chairs &amp; Chairmats</td>
      <td>Hon Olson Stacker Stools</td>
      <td>Large Box</td>
    </tr>
    <tr>
      <th>4</th>
      <td>36646</td>
      <td>Medium</td>
      <td>24</td>
      <td>1168.15</td>
      <td>Express Air</td>
      <td>-743.96</td>
      <td>Muhammed MacIntyre</td>
      <td>Northwest Territories</td>
      <td>Small Business</td>
      <td>Office Supplies</td>
      <td>Storage &amp; Organization</td>
      <td>Tennsco Industrial Shelving</td>
      <td>Large Box</td>
    </tr>
    <tr>
      <th>5</th>
      <td>41696</td>
      <td>Not Specified</td>
      <td>45</td>
      <td>237.28</td>
      <td>Express Air</td>
      <td>-2088.68</td>
      <td>Bryan Mills</td>
      <td>Northwest Territories</td>
      <td>Small Business</td>
      <td>Office Supplies</td>
      <td>Appliances</td>
      <td>Hoover Portapower™ Portable Vacuum</td>
      <td>Large Box</td>
    </tr>
    <tr>
      <th>6</th>
      <td>43267</td>
      <td>Critical</td>
      <td>17</td>
      <td>1368.14</td>
      <td>Express Air</td>
      <td>171.26</td>
      <td>Fred Wasserman</td>
      <td>Northwest Territories</td>
      <td>Home Office</td>
      <td>Office Supplies</td>
      <td>Appliances</td>
      <td>Honeywell Enviracaire® Portable Air Cleaner fo...</td>
      <td>Large Box</td>
    </tr>
    <tr>
      <th>7</th>
      <td>29319</td>
      <td>Low</td>
      <td>21</td>
      <td>4429.69</td>
      <td>Express Air</td>
      <td>983.55</td>
      <td>Filia McAdams</td>
      <td>Atlantic</td>
      <td>Small Business</td>
      <td>Technology</td>
      <td>Copiers and Fax</td>
      <td>Canon PC-428 Personal Copier</td>
      <td>Large Box</td>
    </tr>
    <tr>
      <th>8</th>
      <td>5988</td>
      <td>Not Specified</td>
      <td>40</td>
      <td>19109.61</td>
      <td>Express Air</td>
      <td>-379.29</td>
      <td>Sanjit Chand</td>
      <td>West</td>
      <td>Home Office</td>
      <td>Technology</td>
      <td>Copiers and Fax</td>
      <td>Sharp AL-1530CS Digital Copier</td>
      <td>Large Box</td>
    </tr>
    <tr>
      <th>9</th>
      <td>51073</td>
      <td>Not Specified</td>
      <td>17</td>
      <td>2475.08</td>
      <td>Express Air</td>
      <td>958.80</td>
      <td>Luke Weiss</td>
      <td>West</td>
      <td>Corporate</td>
      <td>Furniture</td>
      <td>Office Furnishings</td>
      <td>3M Polarizing Task Lamp with Clamp Arm, Light ...</td>
      <td>Large Box</td>
    </tr>
  </tbody>
</table>
</div>




```python
#NAMES OF ALL THE COLUMNS
sales.columns
```




    Index(['Order_ID', 'Order_Priority', 'Order_Quantity', 'Sales', 'Ship_Mode',
           'Profit', 'Customer_Name', 'Region', 'Customer_Segment',
           'Product_Category', 'Product_Sub-Category', 'Product_Name',
           'Product_Container'],
          dtype='object')




```python
sales.Order_ID
```




    0        643
    1       8995
    2       9127
    3      26272
    4      36646
           ...  
    725    56101
    726     1059
    727     1059
    728     1826
    729    20003
    Name: Order_ID, Length: 730, dtype: int64




```python
sales.shape
```




    (730, 13)




```python
len(sales['Order_ID'].unique())

```




    571




```python
len(sales['Product_Name'].unique())

```




    445




```python
sales=sales.drop(columns='Order_ID')
sales=sales.drop(columns='Product_Name')
```


```python
sales.columns
```




    Index(['Order_Priority', 'Order_Quantity', 'Sales', 'Ship_Mode', 'Profit',
           'Customer_Name', 'Region', 'Customer_Segment', 'Product_Category',
           'Product_Sub-Category', 'Product_Container'],
          dtype='object')




```python
sales.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 730 entries, 0 to 729
    Data columns (total 11 columns):
     #   Column                Non-Null Count  Dtype  
    ---  ------                --------------  -----  
     0   Order_Priority        730 non-null    object 
     1   Order_Quantity        730 non-null    int64  
     2   Sales                 730 non-null    float64
     3   Ship_Mode             730 non-null    object 
     4   Profit                730 non-null    float64
     5   Customer_Name         730 non-null    object 
     6   Region                730 non-null    object 
     7   Customer_Segment      730 non-null    object 
     8   Product_Category      730 non-null    object 
     9   Product_Sub-Category  730 non-null    object 
     10  Product_Container     730 non-null    object 
    dtypes: float64(2), int64(1), object(8)
    memory usage: 62.9+ KB
    


```python
#To get Stastical Information :
sales.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order_Quantity</th>
      <th>Sales</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>730.000000</td>
      <td>730.000000</td>
      <td>730.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>24.857534</td>
      <td>1502.777653</td>
      <td>207.479233</td>
    </tr>
    <tr>
      <th>std</th>
      <td>14.182970</td>
      <td>2893.936648</td>
      <td>878.631028</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>8.600000</td>
      <td>-4437.910000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>13.000000</td>
      <td>171.098375</td>
      <td>-77.132500</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>25.000000</td>
      <td>438.700000</td>
      <td>0.035000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>37.000000</td>
      <td>1480.855000</td>
      <td>180.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>50.000000</td>
      <td>27663.920000</td>
      <td>8417.570000</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.countplot(sales.Ship_Mode)
sales.Ship_Mode.value_counts()
```




    Regular Air    579
    Express Air    151
    Name: Ship_Mode, dtype: int64




![png](output_14_1.png)


# CUSTOMER SEGMENT


```python
plt.figure(figsize = (5,5))
corp = sales.loc[sales['Customer_Segment'] == 'Corporate'].count()[0]
cons = sales.loc[sales['Customer_Segment'] == 'Consumer'].count()[0]
hoff = sales.loc[sales['Customer_Segment'] == 'Home Office'].count()[0]
sbiz = sales.loc[sales['Customer_Segment'] == 'Small Business'].count()[0]
explode = (0.1, 0.1, 0.1, 0.1)
labels = ['Corporate', 'Consumer', 'Home Office', 'Small Business']
plt.pie([corp, cons, hoff, sbiz], labels = labels, autopct = '%.2f %%', explode = explode)
plt.title("Customer Segment")
plt.show()

sales.Customer_Segment.value_counts()
```


![png](output_16_0.png)





    Corporate         518
    Consumer          153
    Home Office        31
    Small Business     28
    Name: Customer_Segment, dtype: int64



# PRODUCT CATEGORY


```python
sns.countplot(sales.Product_Category)
sales.Product_Category.value_counts()
```




    Office Supplies    447
    Technology         185
    Furniture           98
    Name: Product_Category, dtype: int64




![png](output_18_1.png)


PRODUCT CONTAINER


```python
sns.countplot(sales.Product_Container)
sales.Product_Container.value_counts()
```




    Small Box     606
    Large Box      63
    Medium Box     61
    Name: Product_Container, dtype: int64




![png](output_20_1.png)


# ORDER QUANTITY


```python
sns.boxplot(sales['Order_Quantity'])
```




    <matplotlib.axes._subplots.AxesSubplot at 0x2224fa789a0>




![png](output_22_1.png)



```python
sales.Profit.describe()
```




    count     730.000000
    mean      207.479233
    std       878.631028
    min     -4437.910000
    25%       -77.132500
    50%         0.035000
    75%       180.000000
    max      8417.570000
    Name: Profit, dtype: float64




```python
sales.Sales.describe()
```




    count      730.000000
    mean      1502.777653
    std       2893.936648
    min          8.600000
    25%        171.098375
    50%        438.700000
    75%       1480.855000
    max      27663.920000
    Name: Sales, dtype: float64



# PROFIT VS SALES


```python
sns.relplot('Sales', 'Profit', data = sales)
```




    <seaborn.axisgrid.FacetGrid at 0x2224ee5a1c0>




![png](output_26_1.png)


For most of the purchases, the profit is increasing with increasing sales. Hence, there is a positive correlation between sales nd profit. Most sales lie between 0 and 10000.


```python
sns.relplot('Sales', 'Profit', data = sales, hue = 'Ship_Mode')
```




    <seaborn.axisgrid.FacetGrid at 0x2224f98d1f0>




![png](output_28_1.png)



```python
sns.relplot('Sales', 'Profit', data = sales, kind = 'line')
```




    <seaborn.axisgrid.FacetGrid at 0x2224fbad6d0>




![png](output_29_1.png)


# PROFIT VS PRODUCT CATEGORY


```python
sns.catplot(x = 'Product_Category', y = 'Profit', data = sales, kind = 'box', height = 6)
```




    <seaborn.axisgrid.FacetGrid at 0x2224fc3a040>




![png](output_31_1.png)


# PROFIT FROM DIFFERENT REGIONS


```python
sns.catplot(x = 'Region', y = 'Profit', data = sales, kind = 'bar', aspect= 10/5)
```




    <seaborn.axisgrid.FacetGrid at 0x2224fcbe1f0>




![png](output_33_1.png)


# DISTRIBUTION PLOT FOR PROFIT


```python
sns.distplot(sales.Profit)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x2224fd397c0>




![png](output_35_1.png)


Highest density of profit lies between -77 to 180

# SALES VS CUSTOMER SEGMENT


```python
sns.relplot('Customer_Segment', 'Sales', data = sales, kind = 'line')
```




    <seaborn.axisgrid.FacetGrid at 0x2224fb2e9a0>




![png](output_38_1.png)


Though the highest number of purchases are from Corporate Sector, the highest sales are from Home Office Segment.

# PROFIT VS PRODUCT CATEGORY


```python
sns.relplot('Product_Category', 'Profit', data = sales, kind = 'line')
```




    <seaborn.axisgrid.FacetGrid at 0x2224fb5eb50>




![png](output_41_1.png)


As observed, highest sales and profit are from Technology products.


```python
sns.pairplot(sales)
```




    <seaborn.axisgrid.PairGrid at 0x2224f8c95e0>




![png](output_43_1.png)



```python

```
